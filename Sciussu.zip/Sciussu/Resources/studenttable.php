<?php
  require_once"admin/connect.php";

  $select_stats = "SELECT * FROM stats WHERE stat_id = 1";
  $query_stats = mysqli_query($conn,$select_stats);
  while ($row = mysqli_fetch_array($query_stats)) {
    $gencount = $row['stat_two'];
  }
?>

<!DOCTYPE html>
<html>
<head>
 <link rel="icon" href="resources/SCIUS LOGO.png">
 <title>โครงการ วมว. มหาวิทยาลัยศิลปากร โรงเรียนสิรินธรราชวิทยาลัย</title>
 <link rel="stylesheet" href="style.css">
 <meta name="viewport" content="width=device-width, initial-scale=1.0">
 <meta charset="UTF-8">
 <meta http-equiv=Content-Type content="text/html; charset=utf-8">
 <style>

 @font-face {
   font-family: Silapakorn-Light;
   src: url(resources/silapakorn72-light_beta05.ttf);
 }
 @font-face {
   font-family: Silapakorn-Bold;
   src: url(resources/silapakorn72-bold_beta05.ttf);
 }
 @font-face {
   font-family: Silapakorn-Regular;
   src: url(resources/silapakorn72-regular_beta05.ttf);
 }

.footer {
   width: 100vw;
   background-color: #40826d;
   color: white;
   text-align: center;
   font-family: Silapakorn-Regular;
   padding: 1vw;
}

::-webkit-scrollbar {
display: none;
}

</style>
</head>
<body>
  
 <div id="desktop_elements">

   <div style="position:absolute; top:0vw; left:0vw;">
      <svg style="position:relative; top:0vw; left:10vw;" width="80vw" viewBox="0 0 80 20">
          <rect x="0" y="0" width="8" height="20" fill="#fff"/>
      </svg>
        <?php
         $i = 0;
         while ($i<$gencount) {
         $i++
         ?>

       <svg style="position:relative; top:0vw; left:10vw;" width="80vw" height="8vw" viewBox="0 0 80 8">
         <text x="0" y="3.8" style="font-size:0.18rem; font-family:Silapakorn-Regular;" fill="#1d5242">รุ่นที่ <?php echo $i; ?></text>
         <text x="7.5" y="3.8" style="font-size:0.10rem; font-family:Silapakorn-Regular;" fill="#1d5242">(รุ่นที่ <?php echo $i+7; ?> ของโครงการ วมว. ทั่วประเทศ และ รุ่นที่ <?php echo $i+21; ?> ของโรงเรียนสิรินธรราชวิทยาลัย)</text>
         <rect x="0" y="4.8" rx="1"width="80" height="5" border="1" fill="#40826d"/>
         <text x="4" y="6.8" dominant-baseline="middle" text-anchor="middle" style="font-size:0.11rem; font-family:Silapakorn-Regular;" fill="white">เลขที่</text>
         <text x="12" y="6.8" dominant-baseline="middle" text-anchor="middle" style="font-size:0.11rem; font-family:Silapakorn-Regular;" fill="white">ชื่อเล่น</text>
         <text x="28" y="6.8" dominant-baseline="middle" text-anchor="middle" style="font-size:0.11rem; font-family:Silapakorn-Regular;" fill="white">ชื่อ-นามสกุล</text>
         <text x="56" y="6.8" dominant-baseline="middle" text-anchor="middle" style="font-size:0.11rem; font-family:Silapakorn-Regular;" fill="white">การศึกษาต่อ</text>
         <text x="76" y="6.8" dominant-baseline="middle" text-anchor="middle" style="font-size:0.11rem; font-family:Silapakorn-Regular;" fill="white">โครงงาน</text>
       </svg>

         <?php
         $j = 0;
         while ($j<100) {
             $j++;
       $select_stu = "SELECT * FROM student WHERE stu_gen = $i AND stu_no = $j";

       $query_stu = mysqli_query($conn,$select_stu);

       while ($row = mysqli_fetch_array($query_stu)) {
         $no = $row['stu_no'];
         $nick = $row['stu_nick'];
         $name = $row['stu_name'];
         $uni = $row['stu_uni'];
         $image = $row['stu_img'];
         $proj = $row['stu_proj'];



      ?>
        <svg style="position:relative; top:0vw; left:10vw;" width="80vw" height="3.2vw" viewBox="0 0 80 3.2">
          <rect x="0" y="0" width="80" height="3.2" border="1" fill="<?php
          if ($j % 2 == 0) {
            echo '#daf0e9';
          } elseif ($j % 2 == 1){
            echo '#edf7f4';
          }



          ?>"/>
          <text x="4" y="2" dominant-baseline="middle" text-anchor="middle" style="font-size:0.11rem; font-family:Silapakorn-Regular;" fill="#1d5242"><?php echo $no;?></text>
          <text x="12" y="2" dominant-baseline="middle" text-anchor="middle" style="font-size:0.11rem; font-family:Silapakorn-Regular;" fill="#1d5242"><?php echo $nick;?></text>
          <text x="16.5" y="2" dominant-baseline="middle" style="font-size:0.11rem; font-family:Silapakorn-Regular;" fill="#1d5242"><?php echo $name;?></text>
          <text x="40.5" y="2" dominant-baseline="middle" style="font-size:0.09rem; font-family:Silapakorn-Regular;" fill="#1d5242"><?php echo $uni;?></text>
          <?php

          $select_proj = "SELECT * FROM projects WHERE proj_id = $proj";

          $query_proj = mysqli_query($conn,$select_proj);

           while ($row = mysqli_fetch_array($query_proj)) {

             $code = $row['proj_code'];
             $proj_id = $row['proj_id'];

           }
          ?>
          <?php echo $proj_id ?>
          <a href="project.php?proj=<?php echo $proj_id ?>">
          <text x="76" y="2" dominant-baseline="middle" text-anchor="middle" style="font-size:0.10rem; font-family:Silapakorn-Regular;" fill="#1d5242">
            <?php echo $code ?>
          </text>
          </a>
          <line x1="8" y1="0.5" x2="8" y2="2.7" style="stroke:#fff;stroke-width:0.25" stroke-linecap="round" />
          <line x1="16" y1="0.5" x2="16" y2="2.7" style="stroke:#fff;stroke-width:0.25" stroke-linecap="round" />
          <line x1="40" y1="0.5" x2="40" y2="2.7" style="stroke:#fff;stroke-width:0.25" stroke-linecap="round" />
          <line x1="72" y1="0.5" x2="72" y2="2.7" style="stroke:#fff;stroke-width:0.25" stroke-linecap="round" />
        </svg>

    <?php }}
    ?>
      <svg style="position:relative; top:0vw; left:10vw;" width="80vw" height="1vw" viewBox="0 0 80 1">
      </svg>
    <?php } ?>
    <a href="studentgallery.php">
      <img style="position:absolute; top:15vw; left:80vw; width:10vw;"  src="img/stu icon table.svg">
    </a>
    <div class="footer" style="position:relative; top:15vw;">
      <a href="admin/login.php" style="color:white;">Login as administrator</a>
    </div>
  </div>



   <div id="desktop_menubar">
       <div id="desktop_menubarbg">
         <img id="desktop_menubar_icons" src="resources/sciussu-menubar-icons.svg">
         <img id="desktop_menubar_longname" src="resources/sciussu-menubar-th-title.svg" >
         <svg id="desktop_menubar_rect" width="100vw" viewBox="0 0 80 8">
           <rect x="0" y="0" width="80" height="8" opacity=0.2 style="fill:#000"/>
           <rect x="0" y="0" width="80" height="7.65" style="fill:#40826d"/>
         </svg>
         <svg id="desktop_menubar_circle" height="16.8vw" viewBox="0 0 80 80">
           <circle cx="40" cy="40" r="35" style="fill:#40826d" />
         </svg>
         <b id="desktop_menubar_title_th">
           โครงการ วมว.
         </b>
         <b id="desktop_menubar_subtitle_th">
           โรงเรียนสิรินธรราชวิทยาลัย มหาวิทยาลัยศิลปากร
         </b>
       </div>

     <div id="desktop_iconlang">
       <div class="icon">
         <a href="pers-en.php?redirect=1" height="9.4vw" width="6.25vw">
           <svg height="9.4vw" width="6.25vw" viewBox="0 0 80 120">
             <circle cx="40" cy="40" r="35" fill="white" opacity="0.1"/>
             <rect x="0" y="85" width="80" height="30" style="fill:#fff;stroke-width:4;stroke:#40826d"/>
             <text x="20" y="106" fill=#40826d style="font-size: 18px; font-family:Silapakorn-Bold;">ภาษา</text>
           </svg>
         </a>
       </div>
     </div>

     <div id="desktop_iconcont">
       <div class="icon">
         <a href="cont.php" height="9.4vw" width="6.25vw">
           <svg height="9.4vw" width="6.25vw" viewBox="0 0 80 120">
             <circle cx="40" cy="40" r="35" fill="white"opacity="0.1"/>
             <rect x="0" y="85" width="80" height="30" style="fill:#fff;stroke-width:4;stroke:#40826d"/>
             <text x="18" y="106" fill=#40826d style="font-size: 18px; font-family:Silapakorn-Bold;">ติดต่อ</text>
           </svg>
         </a>
       </div>
     </div>

     <div id="desktop_iconacti">
       <div class="icon">
         <a href="acti.php" height="9.4vw" width="6.25vw">
           <svg height="9.4vw" width="6.25vw" viewBox="0 0 80 120">
             <circle cx="40" cy="40" r="35" fill="white"opacity="0.1"/>
             <rect x="0" y="85" width="80" height="30" style="fill:#fff;stroke-width:4;stroke:#40826d"/>
             <text x="12" y="106" fill=#40826d style="font-size: 18px; font-family:Silapakorn-Bold;">กิจกรรม</text>
           </svg>
         </a>
       </div>
     </div>

     <div id="desktop_iconpers">
       <div class="icon">
         <a href="pers.php" height="9.4vw" width="6.25vw">
           <svg height="9.4vw" width="6.25vw" viewBox="0 0 80 120">
             <circle cx="40" cy="40" r="35" fill="white"opacity="0.1"/>
             <rect x="0" y="85" width="80" height="30" style="fill:#fff;stroke-width:4;stroke:#40826d"/>
             <text x="13" y="106" fill=#40826d style="font-size: 18px; font-family:Silapakorn-Bold;">บุคลากร</text>
           </svg>
         </a>
       </div>
     </div>

     <div id="desktop_iconnews">
       <div class="icon">
         <a href="news.php" height="9.4vw" width="6.25vw">
           <svg height="9.4vw" width="6.25vw" viewBox="0 0 80 120">
             <circle cx="40" cy="40" r="35" fill="white"opacity="0.1"/>
             <rect x="0" y="85" width="80" height="30" style="fill:#fff;stroke-width:4;stroke:#40826d"/>
             <text x="14" y="106" fill=#40826d style="font-size: 18px; font-family:Silapakorn-Bold;">ประกาศ</text>
           </svg>
         </a>
       </div>
     </div>

     <div id="desktop_iconinfo">
       <div class="icon">
         <a href="info.php" height="9.4vw" width="6.25vw">
           <svg height="9.4vw" width="6.25vw" viewBox="0 0 80 120">
             <circle cx="40" cy="40" r="35" fill="white"opacity="0.1"/>
             <rect x="0" y="85" width="80" height="30" style="fill:#fff;stroke-width:4;stroke:#40826d"/>
             <text x="4" y="106" fill=#40826d style="font-size: 14px; font-family:Silapakorn-Bold;">ข้อมูลเบื้องต้น</text>
           </svg>
         </a>
       </div>
     </div>

     <div id="desktop_iconhome">
       <div class="icon">
         <a href="index.php" height="9.4vw" width="6.25vw">
           <svg height="9.4vw" width="6.25vw" viewBox="0 0 80 120">
             <circle cx="40" cy="40" r="35" fill="white"opacity="0.1"/>
             <rect x="0" y="85" width="80" height="30" style="fill:#fff;stroke-width:4;stroke:#40826d"/>
             <text x="12" y="106" fill=#40826d style="font-size: 18px; font-family:Silapakorn-Bold;">หน้าหลัก</text>
           </svg>
         </a>
       </div>
     </div>
     <div id="desktop_logo">
       <a target="_blank" href="http://scius.most.go.th/">
       <img width = "100%" src="resources/SCIUS LOGO.png">
       </a>
     </div>
   </div>



  </div>
 <div id="mobile_elements">

   <div style="overflow-x:visible; position:absolute; top:0vw; left:0vw;">
      <svg style="position:relative; top:0vw; left:10vw;" width="80vw" viewBox="0 0 80 30">
          <rect x="0" y="0" width="8" height="30" fill="#fff"/>
      </svg>
        <svg style="position:relative; top:0vw; left:3vw;" width="163vw" height="2vw" viewBox="0 0 80 1">
        </svg>
        <?php
         $i = 0;
         while ($i<$gencount) {
         $i++
         ?>

       <svg style="position:relative; top:0vw; left:3vw;" width="160vw" height="16vw" viewBox="0 0 80 8">
         <text x="0" y="3.8" style="font-size:0.18rem; font-family:Silapakorn-Regular;" fill="#1d5242">รุ่นที่ <?php echo $i; ?></text>
         <text x="7.5" y="3.8" style="font-size:0.10rem; font-family:Silapakorn-Regular;" fill="#1d5242">(รุ่นที่ <?php echo $i+7; ?> ของโครงการ วมว. ทั่วประเทศ และ รุ่นที่ <?php echo $i+21; ?> ของโรงเรียนสิรินธรราชวิทยาลัย)</text>
         <rect x="0" y="4.8" rx="1"width="80" height="5" border="1" fill="#40826d"/>
         <text x="4" y="6.8" dominant-baseline="middle" text-anchor="middle" style="font-size:0.11rem; font-family:Silapakorn-Regular;" fill="white">เลขที่</text>
         <text x="12" y="6.8" dominant-baseline="middle" text-anchor="middle" style="font-size:0.11rem; font-family:Silapakorn-Regular;" fill="white">ชื่อเล่น</text>
         <text x="28" y="6.8" dominant-baseline="middle" text-anchor="middle" style="font-size:0.11rem; font-family:Silapakorn-Regular;" fill="white">ชื่อ-นามสกุล</text>
         <text x="56" y="6.8" dominant-baseline="middle" text-anchor="middle" style="font-size:0.11rem; font-family:Silapakorn-Regular;" fill="white">การศึกษาต่อ</text>
         <text x="76" y="6.8" dominant-baseline="middle" text-anchor="middle" style="font-size:0.11rem; font-family:Silapakorn-Regular;" fill="white">โครงงาน</text>
       </svg>


         <?php
         $j = 0;
         while ($j<100) {
             $j++;
       $select_stu = "SELECT * FROM student WHERE stu_gen = $i AND stu_no = $j";

       $query_stu = mysqli_query($conn,$select_stu);

       while ($row = mysqli_fetch_array($query_stu)) {
         $no = $row['stu_no'];
         $nick = $row['stu_nick'];
         $name = $row['stu_name'];
         $uni = $row['stu_uni'];
         $image = $row['stu_img'];
         $proj = $row['stu_proj'];

      ?>
        <svg style="position:relative; top:0vw; left:3vw;" width="160vw" height="6.4vw" viewBox="0 0 80 3.2">
          <rect x="0" y="0" width="80" height="3.2" border="1" fill="<?php
          if ($j % 2 == 0) {
            echo '#daf0e9';
          } elseif ($j % 2 == 1){
            echo '#edf7f4';
          }
          ?>"/>
          <text x="4" y="2" dominant-baseline="middle" text-anchor="middle" style="font-size:0.11rem; font-family:Silapakorn-Regular;" fill="#1d5242"><?php echo $no;?></text>
          <text x="12" y="2" dominant-baseline="middle" text-anchor="middle" style="font-size:0.11rem; font-family:Silapakorn-Regular;" fill="#1d5242"><?php echo $nick;?></text>
          <text x="16.5" y="2" dominant-baseline="middle" style="font-size:0.11rem; font-family:Silapakorn-Regular;" fill="#1d5242"><?php echo $name;?></text>
          <text x="40.5" y="2" dominant-baseline="middle" style="font-size:0.09rem; font-family:Silapakorn-Regular;" fill="#1d5242"><?php echo $uni;?></text>
          <?php

          $select_proj = "SELECT * FROM projects WHERE proj_id = $proj";

          $query_proj = mysqli_query($conn,$select_proj);

           while ($row = mysqli_fetch_array($query_proj)) {

             $code = $row['proj_code'];
             $proj_id = $row['proj_id'];

           }
          ?>
          <?php echo $proj_id ?>
          <a href="project.php?proj=<?php echo $proj_id ?>">
          <text x="76" y="2" dominant-baseline="middle" text-anchor="middle" style="font-size:0.11rem; font-family:Silapakorn-Regular;" fill="#1d5242">
            <?php echo $code ?>
          </text>
          </a>
          <line x1="8" y1="0.5" x2="8" y2="2.7" style="stroke:#fff;stroke-width:0.25" stroke-linecap="round" />
          <line x1="16" y1="0.5" x2="16" y2="2.7" style="stroke:#fff;stroke-width:0.25" stroke-linecap="round" />
          <line x1="40" y1="0.5" x2="40" y2="2.7" style="stroke:#fff;stroke-width:0.25" stroke-linecap="round" />
          <line x1="72" y1="0.5" x2="72" y2="2.7" style="stroke:#fff;stroke-width:0.25" stroke-linecap="round" />
        </svg>

    <?php }}
    ?>
      <svg style="position:relative; top:0vw; left:10vw;" width="80vw" height="1vw" viewBox="0 0 80 1">
      </svg>
    <?php } ?>

    <a href="studentgallery.php">
      <img style="position:absolute; top:20vw; left:10vw; width:20vw;"  src="img/stu icon table.svg">
    </a>


   <div class="mobile_menubar">
     <img style="position:fixed; top:0vw; "src="resources/sciussu-menubar-th-mobile.svg">


     <div id="mobile_logo">
       <a target="_blank" href="http://scius.most.go.th/">
       <img width = "100%" src="resources/SCIUS LOGO.png">
       </a>
     </div>

     <div id="mobile_iconlang">
       <div class="icon">
         <a href="pers-en.php?redirect=1" height="15vw" width="15vw">
           <svg height="15vw" width="15vw" viewBox="0 0 80 80">
             <circle cx="40" cy="35" r="35" fill="white" opacity="0.1"/>
           </svg>
         </a>
       </div>
     </div>

     <div id="mobile_iconmenu">
       <div>
         <element onclick="menumobile_on()">
           <svg height="15vw" width="15vw" viewBox="0 0 80 80">
             <circle cx="40" cy="35" r="35" fill="white" opacity="0.0"/>
           </svg>
         </element>
       </div>
     </div>

     <div id="mobile_menu_on">
       <img src="resources/sciussu-mobile-menu-th.svg" >
       <div id="mobile_menu_off" class="icon">
         <element onclick="menumobile_off()">
           <svg height="15vw" width="15vw" viewBox="0 0 80 80">
             <circle cx="40" cy="35" r="35" fill="white" opacity="0.1"/>
           </svg>
         </element>
       </div>

       <div id="mobile_iconcont" class="icon">
         <a href="cont.php" height="9.4vw" width="40vw">
           <svg height="10vw" width="56vw" viewBox="0 0 56 10">
             <rect x="0" y="0" rx="4" ry="4" width="56" height="10" fill="white"opacity="0.1"/>
           </svg>
         </a>
       </div>

       <div id="mobile_iconacti" class="icon">
         <a href="acti.php" height="9.4vw" width="40vw">
           <svg height="10vw" width="56vw" viewBox="0 0 56 10">
             <rect x="0" y="0" rx="4" ry="4" width="56" height="10" fill="white"opacity="0.1"/>
           </svg>
         </a>
       </div>

       <div id="mobile_iconpers" class="icon">
         <a href="pers.php" height="9.4vw" width="40vw">
           <svg height="10vw" width="56vw" viewBox="0 0 56 10">
             <rect x="0" y="0" rx="4" ry="4" width="56" height="10" fill="white"opacity="0.1"/>
           </svg>
         </a>
       </div>

       <div id="mobile_iconnews" class="icon">
         <a href="news.php" height="9.4vw" width="40vw">
           <svg height="10vw" width="56vw" viewBox="0 0 56 10">
             <rect x="0" y="0" rx="4" ry="4" width="56" height="10" fill="white"opacity="0.1"/>
           </svg>
         </a>
       </div>

       <div id="mobile_iconinfo" class="icon">
         <a href="info.php" height="9.4vw" width="40vw">
           <svg height="10vw" width="56vw" viewBox="0 0 56 10">
             <rect x="0" y="0" rx="4" ry="4" width="56" height="10" fill="white"opacity="0.1"/>
           </svg>
         </a>
       </div>

       <div id="mobile_iconhome" class="icon">
         <a href="index.php" height="9.4vw" width="40vw">
           <svg height="10vw" width="56vw" viewBox="0 0 56 10">
             <rect x="0" y="0" rx="4" ry="4" width="56" height="10" fill="white"opacity="0.1"/>
           </svg>
         </a>
       </div>
   </div>


   <div class="footer" style="position:relative; top:15vw;">
     <a href="admin/login.php" style="color:white;">Login as administrator</a>
   </div>


 </div>
 <script src="javascripts/rellax.min.js"></script>
 <script>
   var rellax = new Rellax('.rellax',{center:true});
 </script>
</body>

<script>
function menumobile_on() {
document.getElementById("mobile_menu_on").style.display = "block";
document.getElementById("mobile_menu_on").style.opacity = "1";
document.getElementById("mobile_menu_off").style.display = "block";
}
function menumobile_off() {
document.getElementById("mobile_menu_on").style.display = "none";
document.getElementById("mobile_menu_on").style.opacity = "0";
}

window.onscroll = function() {scrollFunction()};

 function scrollFunction() {

 if (document.body.scrollTop > 80 || document.documentElement.scrollTop > 80) {
   document.getElementById("desktop_menubar_rect").style.top = "-3vw";
   document.getElementById("desktop_menubar_circle").style.top = "-10vw";
   document.getElementById("desktop_logo").style.width = "5.5vw";
   document.getElementById("desktop_menubar_title_th").style.top = "0.8vw";
   document.getElementById("desktop_menubar_title_th").style.left = "8vw";
   document.getElementById("desktop_menubar_subtitle_th").style.opacity = "0";
   document.getElementById("desktop_menubar_subtitle_th").style.left = "8vw";
   document.getElementById("desktop_menubar_longname").style.top = "-10vw";
   document.getElementById("desktop_menubar_icons").style.top = "-1.5vw";
   document.getElementById("desktop_iconlang").style.top = "0.1vw";
   document.getElementById("desktop_iconcont").style.top = "0.1vw";
   document.getElementById("desktop_iconacti").style.top = "0.1vw";
   document.getElementById("desktop_iconpers").style.top = "0.1vw";
   document.getElementById("desktop_iconnews").style.top = "0.1vw";
   document.getElementById("desktop_iconinfo").style.top = "0.1vw";
   document.getElementById("desktop_iconhome").style.top = "0.1vw";
 } else {
   document.getElementById("desktop_menubar_rect").style.top = "0vw";
   document.getElementById("desktop_menubar_circle").style.top = "-1.5vw";
   document.getElementById("desktop_logo").style.width = "12.8vw";
   document.getElementById("desktop_menubar_title_th").style.top = "1vw";
   document.getElementById("desktop_menubar_title_th").style.left = "15.6vw";
   document.getElementById("desktop_menubar_subtitle_th").style.opacity = "1";
   document.getElementById("desktop_menubar_subtitle_th").style.left = "16vw";
   document.getElementById("desktop_menubar_longname").style.top = "0vw";
   document.getElementById("desktop_menubar_icons").style.top = "0vw";
   document.getElementById("desktop_iconlang").style.top = "1.6vw";
   document.getElementById("desktop_iconcont").style.top = "1.6vw";
   document.getElementById("desktop_iconacti").style.top = "1.6vw";
   document.getElementById("desktop_iconpers").style.top = "1.6vw";
   document.getElementById("desktop_iconnews").style.top = "1.6vw";
   document.getElementById("desktop_iconinfo").style.top = "1.6vw";
   document.getElementById("desktop_iconhome").style.top = "1.6vw";
 }
 if (document.body.scrollTop > 1700 || document.documentElement.scrollTop > 1700) {
   document.getElementById("map").style.right = "2vw";
   document.getElementById("map").style.opacity = "1";
 }
 if (document.body.scrollTop > 500 || document.documentElement.scrollTop > 500) {
   document.getElementById("laurel").style.top = "155.5vw";
   document.getElementById("laurel").style.opacity = "1";
 }
}

</script>

</html>
