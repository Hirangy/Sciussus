<?php
$dt=0.001;
$t=0;
$v=6;
$s=0;
$g=-9.8;
$k=-4.9;
?>
<svg style="fill:black;" viewBox"0 0 1 1">
  <polygon points="<?php
while ($t<2) {
$a=$g+$k*$v;
$v+=$a*$dt;
$s+=$v*$dt;
$t+=$dt;
echo $s,",",$t," ";
}?>
">
</svg>
