<!DOCTYPE html>
<html>
<head>
  <link rel="icon" href="resources/SCIUS LOGO.png">
  <title>โครงการ วมว. มหาวิทยาลัยศิลปากร โรงเรียนสิรินธรราชวิทยาลัย</title>
  <link rel="stylesheet" href="style.css">
  <link rel="stylesheet" href="stylehome.css">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta charset="UTF-8">
  <meta http-equiv=Content-Type content="text/html; charset=utf-8">
</head>
<body>
  <div>
    <b id="1" style="position:absolute; top:100vw; left:15vw; font-size:10vw; color:#000;">1</b>
    <b id="2" style="position:absolute; top:100vw; left:30vw; font-size:10vw; color:#000;">2</b>
    <b id="3" style="position:absolute; top:100vw; left:45vw; font-size:10vw; color:#000;">3</b>
    <b id="4" style="position:absolute; top:500vw; left:30vw; font-size:10vw; color:#000;">4</b>

  </div>

</body>


  <script>
  window.onscroll = function() {scrollFunction()};
  function scrollFunction() {
    var x = document.documentElement.clientWidth;
    var y = document.documentElement.clientHeight;
    var k = 0.1;
    var pos = 100;
    var h = window.pageYOffset;
    var elem1 = document.getElementById('1');
    elem1.style.top  = pos + 'vw';
    var elem2 = document.getElementById('2');
    var pos2 = pos-0.1*(100*h/x - pos + 50 *y/x);
    elem2.style.top  = pos2 + 'vw';
    var elem3 = document.getElementById('3');
    var pos3 = pos-0.2*(100*h/x - pos + 50 *y/x);
    elem3.style.top  = pos3 + 'vw';
    console.log(scroll,x,y);
  }
  </script>
</html>
