<?php
$dist=0;
$phase=0;
$outer=1.52;
$inner=	1;
$degincouter=26.2;
$degincinner=49.3;
$steps=21;
$i=0;
echo "phase finder by Hirangy";
?> <br /><br /><?php
while ($i<$steps) {

$dist = sqrt(($outer*$outer)+($inner*$inner)-(2*$outer*$inner*cos($phase)));
$rad = asin($inner*sin($phase)/$dist);
$rad2 = asin($outer*sin($phase)/$dist);
if ($dist*$dist < ($outer*$outer)-($inner*$inner) ) {
  $rad2 = 3.14159265 - abs($rad2);
}
echo "days",50*$i,", phase:",$phase*180/3.14159265 ,", deg:",floor($rad*1800/3.14159265)/10,", deg2:",floor($rad2*1800/3.14159265)/10?> <br /><?php
$phase+=($degincinner-$degincouter)*3.14159265/180;
$i++;

}?>


</svg>
