<?php
  require_once "connect.php";
  session_start();
  if(isset($_POST['login'])) {
      $username = mysqli_real_escape_string($conn,$_POST["username"]);
      $password = mysqli_real_escape_string($conn,$_POST["password"]);
      $query = "SELECT * FROM admin WHERE username = '$username' AND password = '$password'";
      $res = mysqli_query($conn, $query);
      if (mysqli_num_rows($res) > 0 ) {
        $_SESSION['username'] = $username;
        echo"<script>alert('Login Successfully');</script>";
        header("location: index.php");
      } else {
        echo"<script>alert('Username or password is incorrect');</script>";
      }
  }
?>
<!DOCTYPE html>
<html lang ="en">
<head>
   <meta charset="UTF-8">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <meta http-equiv="X-UA-Compatible" content="ie=edge">
   <link rel="stylesheet" href="styleadmin.css">
   <title>SCiUS Login Page</title>
   
</head>
<body>

    <center style="margin-top:2vw;">
      <form action="login.php" method="post">
        <table width="400" border="1" align="center">
          <tr>
            <td bgcolor="#40826d" colspan="4" align="center">
              <h1 style="padding:1vw; color:#fff; font-family: Silapakorn-Regular;" > Administrator Login Form</h1>
            </td>
          </tr>
          <tr>
            <td style="font-family: Silapakorn-Regular;"> Username:</td>
            <td> <input type="text" name="username"> </td>
          </tr>
          <tr>
            <td style="font-family: Silapakorn-Regular;"> Password:</td>
            <td> <input type="password" name="password"> </td>
          </tr>
          <tr>
            <td colspan="4" align="right" style="font-family: Silapakorn-Regular;"> <input type="submit" name="login" value="Login"> </td>
          </tr>
        </table>
        <p style="font-family: Silapakorn-Regular;">You must be an admin to login. Click <a href="../index.php" style="font-family: Silapakorn-Regular;">HERE</a> to return home.</p>
      </form>
    </center>

</body>
</html>
