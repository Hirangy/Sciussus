<?php
  require_once "connect.php";
  session_start();

  if (!isset($_SESSION['username'])) {
    header("location: login.php");
  } else {

 ?>


<!DOCTYPE html>
<html>
<head>
 <link rel="icon" href="resources/SCIUS LOGO.png">
 <title>SCiUS View Acitivities Page</title>
 <link rel="stylesheet" href="styleadmin.css">
 <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
  <header>
    <div class="container">
      <h1 style="font-family: Silapakorn-Regular;"> Welcome to the administrator page, <?php echo $_SESSION['username'];?></h1>
    </div>
  </header>
  <section>
    <div class="content" style="font-family: Silapakorn-Regular;">
      <div class="content_grid">
        <div class="sidebar">
          <h1>Welcome: <?php echo $_SESSION['username']?></h1>
          <h3><a href="index.php"> Home Page </a></h3>
          <hr>
          <h3><a href="viewposts.php"> View Posts </a></h3>
          <h3><a href="insertposts.php"> Insert Posts </a></h3>
          <hr>
          <h3><a href="viewactivities.php"> View Activities </a></h3>
          <h3><a href="insertactivities.php"> Insert Activities </a></h3>
          <hr>
          <h3><a href="viewfaculties.php"> View Faculties </a></h3>
          <h3><a href="insertfaculties.php"> Insert Faculties </a></h3>
          <hr>
          <h3><a href="logout.php"> Logout </a></h3>
        </div>
        <div class="showinfo" style="font-family: Silapakorn-Regular;">
          <h1>View All Activities</h1>

          <table border="1">
            <tr>
              <th> Activities ID </th>
              <th> Activities Title </th>
              <th> Activities Author </th>
              <th> Activities Date </th>
              <th> Activities Image </th>
              <th> Activities Content </th>
              <th> Delete </th>
              <th> Edit </th>
            </tr>
            <?php
              $select_acti = "SELECT * FROM activities ORDER BY 1 DESC";

              $query_acti = mysqli_query($conn,$select_acti);

              while ($row = mysqli_fetch_array($query_acti)) {
                $acti_id = $row['acti_id'];
                $acti_title = $row['acti_title'];
                $acti_author = $row['acti_author'];
                $acti_date = $row['acti_date'];
                $acti_image = $row['acti_image'];
                $acti_content = substr($row['acti_content'], 0, 50);

             ?>
             <tr>
               <td><?php echo $acti_id; ?></td>
               <td><?php echo $acti_title; ?></td>
               <td><?php echo $acti_author; ?></td>
               <td><?php echo $acti_date; ?></td>
               <td><img width="160" height="90" src="<?php echo $acti_image; ?>"></td>
               <td><?php echo $acti_content; ?></td>
               <td><a href="deleteactivities.php?del=<?php echo $acti_id; ?>">Delete</a></td>
               <td><a href="editactivities.php?edit=<?php echo $acti_id; ?>">Edit</a></td>
             </tr>


           <?php } ?>
          </table>
        </div>
      </div>
    </div>
  </section>
</body>
</html>

<?php } ?>
