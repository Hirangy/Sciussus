<?php

  $conn = mysqli_connect('sql100.epizy.com', 'epiz_26763869','iJrBBmL0l7Pi', 'epiz_26763869_basiccms');
  mysqli_set_charset($conn, 'utf8');
  if (!$conn) {
    die("Failed to connect to database" . mysqli_error());
  }
?>
