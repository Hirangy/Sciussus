<?php
  session_start();
  require_once "connect.php";
  if (!isset($_SESSION['username'])) {
    header("location: login.php");
  }

  if (isset($_POST['submit'])) {
    $proj_code = $_POST['code'];
    $proj_name_th = $_POST['name_th'];
    $proj_name_en = $_POST['name_en'];
    $proj_abstract = $_POST['abstract'];
    $proj_authors = $_POST['authors'];
    $proj_poster = $_POST['poster'];





    $insert_query = "INSERT INTO projects (proj_code,proj_name_th,proj_name_en,proj_abstract,proj_poster,proj_authors)
    VALUES('$proj_code', '$proj_name_th', '$proj_name_en', '$proj_abstract','$proj_poster','$proj_authors')";

    if (mysqli_query($conn, $insert_query)) {
      echo"<script>alert('Project Published');</script>";
    } else {
      echo"<script>alert('Sum Ting Wong');</script>";
    }
  }


?>

<!DOCTYPE html>
<html>
<head>
 <link rel="icon" href="resources/SCIUS LOGO.png">
 <title>SCiUS Insert Projects Page</title>
 <link rel="stylesheet" href="styleadmin.css">
 <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
  <header>
    <div class="container">
      <h1 style="font-family: Silapakorn-Regular;">Welcome to the administrator page, <?php echo $_SESSION['username'];?></h1>
    </div>
  </header>
  <section>
    <div class="content" style="font-family:Silapakorn-Regular;">
      <div class="content_grid">
        <div class="sidebar">
          <h1>Welcome: <?php echo $_SESSION['username']?></h1>
          <h3><a href="index.php"> Home Page </a></h3>
          <hr>
          <h3><a href="viewposts.php"> View Posts </a></h3>
          <h3><a href="insertposts.php"> Insert Posts </a></h3>
          <hr>
          <h3><a href="viewactivities.php"> View Activities </a></h3>
          <h3><a href="insertactivities.php"> Insert Activities </a></h3>
          <hr>
          <h3><a href="viewfaculties.php"> View Faculties </a></h3>
          <h3><a href="insertfaculties.php"> Insert Faculties </a></h3>
          <hr>
          <h3><a href="viewprojects.php"> View Projects </a></h3>
          <h3><a href="insertprojects.php"> Insert Projects </a></h3>
          <hr>
          <h3><a href="logout.php"> Logout </a></h3>
        </div>
        <div class="showinfo">

          <table border="1">
            <tr>
              <form action="insertprojects.php" method="post" enctype="multipart/form-data">
                <table width="100%" align="center" border="1">
                  <tr>
                    <td align="center" colspan="6"><h1>Insert New Projects</h1></td>
                  </tr>
                  <tr>
                    <td>Project Code</td>
                    <td><input type="text" name="code" size="50"></td>
                  </tr>
                  <tr>
                    <td>Project Name TH</td>
                    <td><input type="text" name="name_th" size="50"></td>
                  </tr>
                  <tr>
                    <td>Project Name EN</td>
                    <td><input type="text" name="name_en" size="50"></td>
                  </tr>
                  <tr>
                    <td>Project Authors</td>
                    <td><input type="text" name="authors" size="50"></td>
                  </tr>
                  <tr>
                    <td>Project Poster</td>
                    <td><input type="text" name="poster" size="50"><p>Upload image <a target="_blank" href="https://imgbb.com/">HERE</a> and link it back. Image will be scaled to idk</p></td>
                  </tr>
                  <tr>
                    <td>Project Abstract</td>
                    <td><textarea name="abstract" col="100" row="15"></textarea></td>
                  </tr>
                  <tr>
                    <td colspan = "6" align="right"><input type="submit" name="submit" value="Publish Now"></td>
                  </tr>
                </table>
              </form>
            </tr>
          </table>
        </div>
      </div>
    </div>
  </section>
</body>
</html>

<?php  ?>
