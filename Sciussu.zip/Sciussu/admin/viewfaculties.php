<?php
  require_once "connect.php";
  session_start();

  if (!isset($_SESSION['username'])) {
    header("location: login.php");
  } else {

 ?>


<!DOCTYPE html>
<html>
<head>
 <link rel="icon" href="resources/SCIUS LOGO.png">
 <title>SCiUS View Facultues Page</title>
 <link rel="stylesheet" href="styleadmin.css">
 <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
  <header>
    <div class="container">
      <h1 style="font-family: Silapakorn-Regular;"> Welcome to the administrator page, <?php echo $_SESSION['username'];?></h1>
    </div>
  </header>
  <section>
    <div class="content" style="font-family: Silapakorn-Regular;">
      <div class="content_grid">
        <div class="sidebar">
          <h1>Welcome: <?php echo $_SESSION['username']?></h1>
          <h3><a href="index.php"> Home Page </a></h3>
          <hr>
          <h3><a href="viewposts.php"> View Posts </a></h3>
          <h3><a href="insertposts.php"> Insert Posts </a></h3>
          <hr>
          <h3><a href="viewactivities.php"> View Activities </a></h3>
          <h3><a href="insertactivities.php"> Insert Activities </a></h3>
          <hr>
          <h3><a href="viewfaculties.php"> View Faculties </a></h3>
          <h3><a href="insertfaculties.php"> Insert Faculties </a></h3>
          <hr>
          <h3><a href="logout.php"> Logout </a></h3>
        </div>
        <div class="showinfo" style="font-family: Silapakorn-Regular;">
          <h1>View All Faculties</h1>

          <table border="1">
            <tr>
              <th> Faculty ID </th>
              <th> Faculty Name TH/EN </th>
              <th> Faculty Position TH/EN </th>
              <th> Faculty Image </th>
              <th> Delete </th>
              <th> Edit </th>
            </tr>
            <?php
              $select_fac = "SELECT * FROM faculty ORDER BY 1 DESC";

              $query_fac = mysqli_query($conn,$select_fac);

              while ($row = mysqli_fetch_array($query_fac)) {
                $fac_id = $row['fac_id'];
                $fac_name_th = $row['fac_name_th'];
                $fac_name_en = $row['fac_name_en'];
                $fac_pos_th = $row['fac_pos_th'];
                $fac_pos_en = $row['fac_pos_en'];
                $fac_image = $row['fac_image'];

             ?>
             <tr>
               <td><?php echo $fac_id; ?></td>
               <td><?php echo $fac_name_th; ?><br><?php echo $fac_name_en; ?></td>
               <td><?php echo $fac_pos_th; ?><br><?php echo $fac_pos_en; ?></td>
               <td><img width="120" height="160" src="<?php echo $fac_image; ?>"></td>
               <td><a href="deletefaculties.php?del=<?php echo $fac_id; ?>">Delete</a></td>
               <td><a href="editfaculties.php?edit=<?php echo $fac_id; ?>">Edit</a></td>
             </tr>


           <?php } ?>
          </table>
        </div>
      </div>
    </div>
  </section>
</body>
</html>

<?php } ?>
