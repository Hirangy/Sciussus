<?php
  require_once "connect.php";
  session_start();

  if (!isset($_SESSION['username'])) {
    header("location: login.php");
  } else {

 ?>


<!DOCTYPE html>
<html>
<head>
 <link rel="icon" href="resources/SCIUS LOGO.png">
 <title>SCiUS Viewposts Page</title>
 <link rel="stylesheet" href="styleadmin.css">
 <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
  <header>
    <div class="container">
      <h1 style="font-family: Silapakorn-Regular;"> Welcome to the administrator page, <?php echo $_SESSION['username'];?></h1>
    </div>
  </header>
  <section>
    <div class="content" style="font-family: Silapakorn-Regular;">
      <div class="content_grid">
        <div class="sidebar">
          <h1>Welcome: <?php echo $_SESSION['username']?></h1>
          <h3><a href="index.php"> Home Page </a></h3>
          <hr>
          <h3><a href="viewposts.php"> View Posts </a></h3>
          <h3><a href="insertposts.php"> Insert Posts </a></h3>
          <hr>
          <h3><a href="viewactivities.php"> View Activities </a></h3>
          <h3><a href="insertactivities.php"> Insert Activities </a></h3>
          <hr>
          <h3><a href="viewfaculties.php"> View Faculties </a></h3>
          <h3><a href="insertfaculties.php"> Insert Faculties </a></h3>
          <hr>
          <h3><a href="logout.php"> Logout </a></h3>
        </div>
        <div class="showinfo" style="font-family: Silapakorn-Regular;">
          <h1>View All Posts</h1>

          <table border="1">
            <tr>
              <th> Post ID </th>
              <th> Post Title </th>
              <th> Post Author </th>
              <th> Post Date </th>
              <th> Post Image </th>
              <th> Post Content </th>
              <th> Delete </th>
              <th> Edit </th>
            </tr>
            <?php
              $select_post = "SELECT * FROM posts ORDER BY 1 DESC";

              $query_post = mysqli_query($conn,$select_post);

              while ($row = mysqli_fetch_array($query_post)) {
                $post_id = $row['post_id'];
                $post_title = $row['post_title'];
                $post_author = $row['post_author'];
                $post_date = $row['post_date'];
                $post_image = $row['post_image'];
                $post_content = substr($row['post_content'], 0, 50);

             ?>
             <tr>
               <td><?php echo $post_id; ?></td>
               <td><?php echo $post_title; ?></td>
               <td><?php echo $post_author; ?></td>
               <td><?php echo $post_date; ?></td>
               <td><img width="160" height="90" src="<?php echo $post_image; ?>"></td>
               <td><?php echo $post_content; ?></td>
               <td><a href="deleteposts.php?del=<?php echo $post_id; ?>">Delete</a></td>
               <td><a href="editposts.php?edit=<?php echo $post_id; ?>">Edit</a></td>
             </tr>


           <?php } ?>
          </table>
        </div>
      </div>
    </div>
  </section>
</body>
</html>

<?php } ?>
