<?php
  session_start();
  require_once "connect.php";
  if (!isset($_SESSION['username'])) {
    header("location: login.php");
  }

    $posts_query = "SELECT * FROM featured WHERE id = 'posts'";
    $run_posts = mysqli_query($conn,$posts_query);
    while ($posts_row = mysqli_fetch_array($run_posts)) {
      $posts_one = $posts_row['one'];
      $posts_two = $posts_row['two'];
      $posts_three = $posts_row['three'];
      $posts_four = $posts_row['four'];
      $posts_five = $posts_row['five'];
    }

    $activities_query = "SELECT * FROM featured WHERE id = 'activities'";
    $run_activities = mysqli_query($conn,$activities_query);
    while ($activities_row = mysqli_fetch_array($run_activities)) {
      $activities_one = $activities_row['one'];
      $activities_two = $activities_row['two'];
      $activities_three = $activities_row['three'];
      $activities_four = $activities_row['four'];
      $activities_five = $activities_row['five'];
    }

    $stats_query = "SELECT * FROM stats WHERE stat_id = '1'";
    $run_stats = mysqli_query($conn,$stats_query);
    while ($stats_row = mysqli_fetch_array($run_stats)) {
      $stats_one = $stats_row['stat_one'];
      $stats_two = $stats_row['stat_two'];
      $stats_three = $stats_row['stat_three'];
      $stats_four = $stats_row['stat_four'];
      $stats_five = $stats_row['stat_five'];
    }

    $stats_query = "SELECT * FROM stats WHERE stat_id = '2'";
    $run_stats = mysqli_query($conn,$stats_query);
    while ($stats_row = mysqli_fetch_array($run_stats)) {
      $stats_one_pos = $stats_row['stat_one'];
      $stats_two_pos = $stats_row['stat_two'];
      $stats_three_pos = $stats_row['stat_three'];
      $stats_four_pos = $stats_row['stat_four'];
      $stats_five_pos = $stats_row['stat_five'];
    }


  if (isset($_POST['submit'])) {
    $posts_one = $_POST['posts_one'];
    $posts_two = $_POST['posts_two'];
    $posts_three = $_POST['posts_three'];
    $posts_four = $_POST['posts_four'];
    $posts_five = $_POST['posts_five'];
    $activities_one = $_POST['activities_one'];
    $activities_two = $_POST['activities_two'];
    $activities_three = $_POST['activities_three'];
    $activities_four = $_POST['activities_four'];
    $activities_five = $_POST['activities_five'];
    $stats_one = $_POST['stat_one'];
    $stats_two = $_POST['stat_two'];
    $stats_three = $_POST['stat_three'];
    $stats_four = $_POST['stat_four'];
    $stats_five = $_POST['stat_five'];
    $stats_one_pos = $_POST['stat_one_pos'];
    $stats_two_pos = $_POST['stat_two_pos'];
    $stats_three_pos = $_POST['stat_three_pos'];
    $stats_four_pos = $_POST['stat_four_pos'];
    $stats_five_pos = $_POST['stat_five_pos'];
    $about_title1 = $_POST['title1'];
    $about_image1 = $_POST['image1'];
    $about_link1 = $_POST['link1'];
    $about_title2 = $_POST['title2'];
    $about_image2 = $_POST['image2'];
    $about_link2 = $_POST['link2'];
    $about_title3 = $_POST['title3'];
    $about_image3 = $_POST['image3'];
    $about_link3 = $_POST['link3'];
    $about_title4 = $_POST['title4'];
    $about_image4 = $_POST['image4'];
    $about_link4 = $_POST['link4'];
    $fac1 = $_POST['fac_one'];
    $fac2 = $_POST['fac_two'];
    $fac3 = $_POST['fac_three'];
    $fac4 = $_POST['fac_four'];
    $fac5 = $_POST['fac_five'];
    $fac6 = $_POST['fac_six'];
    $fac7 = $_POST['fac_seven'];
    $fac8 = $_POST['fac_eight'];
    $fac9 = $_POST['fac_nine'];
    $fac10 = $_POST['fac_ten'];
    $fac11 = $_POST['fac_eleven'];
    $fac12 = $_POST['fac_twelve'];


    $update_query = "UPDATE featured SET one = '$posts_one', two = '$posts_two' ,three = '$posts_three', four = '$posts_four',five = '$posts_five' WHERE id = 'posts'";
    $update_query1 = "UPDATE featured SET one = '$activities_one', two = '$activities_two' ,three = '$activities_three', four = '$activities_four',five = '$activities_five' WHERE id = 'activities'";
    $update_query2 = " UPDATE stats SET stat_one = '$stats_one', stat_two = '$stats_two' ,stat_three = '$stats_three', stat_four = '$stats_four', stat_five = '$stats_five' WHERE stat_id = '1'";
    $update_query3 = " UPDATE stats SET stat_one = '$stats_one_pos', stat_two = '$stats_two_pos' ,stat_three = '$stats_three_pos', stat_four = '$stats_four_pos', stat_five = '$stats_five_pos' WHERE stat_id = '2'";
    $update_query4 = " UPDATE about SET about_title = '$about_title1', about_image ='$about_image1', about_link ='$about_link1' WHERE about_id = 1";
    $update_query5 = " UPDATE about SET about_title = '$about_title2', about_image ='$about_image2', about_link ='$about_link2' WHERE about_id = 2";
    $update_query6 = " UPDATE about SET about_title = '$about_title3', about_image ='$about_image3', about_link ='$about_link3' WHERE about_id = 3";
    $update_query7 = " UPDATE about SET about_title = '$about_title4', about_image ='$about_image4', about_link ='$about_link4' WHERE about_id = 4";
    $update_query8 = "UPDATE featured SET one = '$fac1', two = '$fac2' ,three = '$fac3', four = '$fac4',five = '$fac5',six = '$fac6',seven = '$fac7',eight = '$fac8',nine = '$fac9', ten = '$fac10', eleven = '$fac11', twelve = '$fac12' WHERE id = 'faculty'";

    if (mysqli_query($conn, $update_query) && mysqli_query($conn, $update_query1) && mysqli_query($conn, $update_query2) && mysqli_query($conn, $update_query3) && mysqli_query($conn, $update_query4)&& mysqli_query($conn, $update_query5)&& mysqli_query($conn, $update_query6)&& mysqli_query($conn, $update_query7)&& mysqli_query($conn, $update_query8)) {
      echo"<script>alert('Page Updated');</script>";
    } else {
      echo"<script>alert('Sum Ting Wong');</script>";
    }
  }


?>

<!DOCTYPE html>
<html>
<head>
 <link rel="icon" href="resources/SCIUS LOGO.png">
 <title>SCiUS Admin Page</title>
 <link rel="stylesheet" href="styleadmin.css">
 <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body style="font-family: Silapakorn-Regular;">
  <header>
    <div class="container">
      <h1 style="font-family: Silapakorn-Regular;"> Welcome to the administrator page, <?php echo $_SESSION['username'];?></h1>
    </div>
  </header>
  <section>
    <div class="content">
      <div class="content_grid">
        <div class="sidebar">
          <h1>Welcome: <?php echo $_SESSION['username']?></h1>
          <h3><a href="index.php"> Home Page </a></h3>
          <hr>
          <h3><a href="viewposts.php"> View Posts </a></h3>
          <h3><a href="insertposts.php"> Insert Posts </a></h3>
          <hr>
          <h3><a href="viewactivities.php"> View Activities </a></h3>
          <h3><a href="insertactivities.php"> Insert Activities </a></h3>
          <hr>
          <h3><a href="viewfaculties.php"> View Faculties </a></h3>
          <h3><a href="insertfaculties.php"> Insert Faculties </a></h3>
          <hr>
          <h3><a href="viewstudents.php"> View Students </a></h3>
          <h3><a href="insertstudents.php"> Insert Students </a></h3>
          <hr>
          <h3><a href="viewprojects.php"> View Projects </a></h3>
          <h3><a href="insertprojects.php"> Insert Projects </a></h3>
          <hr>
          <h3><a href="logout.php"> Logout </a></h3>
        </div>
        <div class="showinfo">

          <table border="1">
            <tr>
              <form action="index.php" method="post" enctype="multipart/form-data">
                <table width="100%" align="center" border="1">
                  <tr>
                    <td align="center" colspan="6"><h1>Featured Posts</h1></td>
                  </tr>
                  <tr>
                    <td>Featured Posts</td>
                    <td>
                      <input type="number" name="posts_one" size="5" value="<?php echo $posts_one;?>">
                      <input type="number" name="posts_two" size="5" value="<?php echo $posts_two;?>">
                      <input type="number" name="posts_three" size="5" value="<?php echo $posts_three;?>">
                      <input type="number" name="posts_four" size="5" value="<?php echo $posts_four;?>">
                      <input type="number" name="posts_five" size="5" value="<?php echo $posts_five;?>">
                    </td>
                  </tr>
                  <?php

                    $select_featured = "SELECT * FROM featured WHERE id = 'posts'";

                    $query_featured = mysqli_query($conn,$select_featured);

                    while ($row = mysqli_fetch_array($query_featured)) {
                      $featured_posts = array($row['one']+0,$row['two']+0,$row['three']+0,$row['four']+0,$row['five']+0);
                   }

                  $i = 0;
                  while ($i<5) {
                    $select_post = "SELECT * FROM posts WHERE post_id = $featured_posts[$i]";

                    $query_post = mysqli_query($conn,$select_post);

                    while ($row = mysqli_fetch_array($query_post)) {
                      $post_id = $row['post_id'];
                      $post_title = $row['post_title'];
                      $post_author = $row['post_author'];
                      $post_date = $row['post_date'];
                      $post_image = $row['post_image'];
                      $post_content = substr($row['post_content'], 0, 50);
                   ?>
                   <tr>
                     <td><?php echo $post_id; ?></td>
                     <td><?php echo $post_title; ?></td>
                     <td><?php echo $post_author; ?></td>
                     <td><?php echo $post_date; ?></td>
                     <td><img width="160" height="90" src="<?php echo $post_image; ?>"></td>
                     <td><?php echo $post_content; ?></td>
                     <td><a href="deleteposts.php?del=<?php echo $post_id; ?>">Delete</a></td>
                     <td><a href="editposts.php?edit=<?php echo $post_id; ?>">Edit</a></td>
                   </tr>


                 <?php }
                 $i++;
                  }

                  ?>
                  <tr>
                    <td>Featured Activities</td>
                    <td>
                      <input type="number" name="activities_one" size="5" value="<?php echo $activities_one;?>">
                      <input type="number" name="activities_two" size="5" value="<?php echo $activities_two;?>">
                      <input type="number" name="activities_three" size="5" value="<?php echo $activities_three;?>">
                      <input type="number" name="activities_four" size="5" value="<?php echo $activities_four;?>">
                      <input type="number" name="activities_five" size="5" value="<?php echo $activities_five;?>">
                    </td>
                  </tr>
                  <?php

                    $select_featured = "SELECT * FROM featured WHERE id = 'activities'";

                    $query_featured = mysqli_query($conn,$select_featured);

                    while ($row = mysqli_fetch_array($query_featured)) {
                      $featured_activities = array($row['one']+0,$row['two']+0,$row['three']+0,$row['four']+0,$row['five']+0);
                   }

                  $i = 0;
                  while ($i<5) {
                    $select_acti = "SELECT * FROM activities WHERE acti_id = $featured_activities[$i]";

                    $query_acti = mysqli_query($conn,$select_acti);

                    while ($row = mysqli_fetch_array($query_acti)) {
                      $acti_id = $row['acti_id'];
                      $acti_title = $row['acti_title'];
                      $acti_author = $row['acti_author'];
                      $acti_date = $row['acti_date'];
                      $acti_image = $row['acti_image'];
                      $acti_content = substr($row['acti_content'], 0, 50);
                   ?>
                   <tr>
                     <td><?php echo $acti_id; ?></td>
                     <td><?php echo $acti_title; ?></td>
                     <td><?php echo $acti_author; ?></td>
                     <td><?php echo $acti_date; ?></td>
                     <td><img width="160" height="90" src="<?php echo $acti_image; ?>"></td>
                     <td><?php echo $acti_content; ?></td>
                     <td><a href="deleteactivities.php?del=<?php echo $acti_id; ?>">Delete</a></td>
                     <td><a href="editactivities.php?edit=<?php echo $acti_id; ?>">Edit</a></td>
                   </tr>

                 <?php }
                 $i++;
                  }
                  ?>
                  <td align="center" colspan="6"><h1>About</h1></td>

                  <?php
                  $i = 0;
                    while ($i<4) {
                    $i++;
                    $select_about = "SELECT * FROM about WHERE about_id = $i";
                    $query_about = mysqli_query($conn,$select_about);
                    while ($row = mysqli_fetch_array($query_about)) {
                      $about_id = $row['about_id'];
                      $about_title = $row['about_title'];
                      $about_image = $row['about_image'];
                      $about_link = $row['about_link'];
                   } ?>
                   <tr>
                     <td><?php echo $about_id; ?></td>
                     <td><text>title:</text><input type="text" name="title<?php echo $i?>" size="12" value="<?php echo $about_title;?>"></td>
                     <td><text>image:</text><input type="text" name="image<?php echo $i?>" size="20" value="<?php echo $about_image;?>"><img width="160" height="90" src="<?php echo $about_image; ?>"></td>
                     <td><text>link:</text><input type="text" name="link<?php echo $i?>" size="20" value="<?php echo $about_link;?>"></td>
                   </tr>
                 <?php }?>
                  <tr>
                  <td align="center" colspan="6"><h1>Stats</h1></td>
                  </tr>
                  <tr>
                  <td>
                    <text>classroom size</text><input type="number" name="stat_one" size="5" value="<?php echo $stats_one;?>"><br><input type="text" name="stat_one_pos" size="5" value="<?php echo $stats_one_pos;?>"><br>
                    <text>years</text><input type="number" name="stat_two" size="5" value="<?php echo $stats_two;?>"><br><input type="text" name="stat_two_pos" size="5" value="<?php echo $stats_two_pos;?>"><br>
                    <text># of classroom</text><input type="number" name="stat_three" size="5" value="<?php echo $stats_three;?>"><br><input type="text" name="stat_three_pos" size="5" value="<?php echo $stats_three_pos;?>"><br>
                    <text>current students</text><input type="number" name="stat_four" size="5" value="<?php echo $stats_four;?>"><br><input type="text" name="stat_four_pos" size="5" value="<?php echo $stats_four_pos;?>"><br>
                    <text>alumnis</text><input type="number" name="stat_five" size="5" value="<?php echo $stats_five;?>"><br><input type="text" name="stat_five_pos" size="5" value="<?php echo $stats_five_pos;?>">
                  </td>
                  </tr>
                </table>
                <table width="100%" align="center" border="1">

                      <tr>
                        <td>University</td>
                      </tr>

                        <?php

                        $select_featured = "SELECT * FROM featured WHERE id = 'faculty'";

                        $query_featured = mysqli_query($conn,$select_featured);

                        while ($row = mysqli_fetch_array($query_featured)) {
                          $featured_fac = array($row['one']+0,$row['two']+0,$row['three']+0,$row['four']+0,$row['five']+0,$row['six']+0,$row['seven']+0,$row['eight']+0,$row['nine']+0,$row['ten']+0,$row['eleven']+0,$row['twelve']+0);
                       }
                         ?>
                      <tr>
                        <td>
                         <input type="number" name="fac_one" size="5" value="<?php echo $featured_fac[0];?>"><br>
                         <input type="number" name="fac_two" size="5" value="<?php echo $featured_fac[1];?>"><br>
                         <input type="number" name="fac_three" size="5" value="<?php echo $featured_fac[2];?>"><br>
                         <input type="number" name="fac_four" size="5" value="<?php echo $featured_fac[3];?>">
                        <td>
                      </tr>

                      <?php

                        $select_featured = "SELECT * FROM featured WHERE id = 'posts'";

                        $query_featured = mysqli_query($conn,$select_featured);

                        while ($row = mysqli_fetch_array($query_featured)) {
                          $featured_posts = array($row['one']+0,$row['two']+0,$row['three']+0,$row['four']+0,$row['five']+0);
                       }

                      $i = 0;
                      while ($i<4) {
                        $select_fac = "SELECT * FROM faculty WHERE fac_id = $featured_fac[$i]";

                        $query_fac = mysqli_query($conn,$select_fac);
                        $i++;
                        while ($row = mysqli_fetch_array($query_fac)) {
                          $fac_id = $row['fac_id'];
                          $fac_name_th = $row['fac_name_th'];
                          $fac_name_en = $row['fac_name_en'];
                          $fac_pos_th = $row['fac_pos_th'];
                          $fac_pos_en = $row['fac_pos_en'];
                          $fac_image = $row['fac_image'];
                       ?>
                       <tr>
                         <td><?php echo $fac_id; ?></td>
                         <td><?php echo $fac_name_th; ?><br><?php echo $fac_name_en; ?></td>
                         <td><?php echo $fac_pos_th; ?><br><?php echo $fac_pos_en; ?></td>
                         <td><img width="120" height="160" src="<?php echo $fac_image; ?>"></td>
                         <td><a href="deletefaculties.php?del=<?php echo $fac_id; ?>">Delete</a></td>
                         <td><a href="editfaculties.php?edit=<?php echo $fac_id; ?>">Edit</a></td>
                       </tr>


                      <?php }
                    } ?>


                      <tr>
                        <td>School</td>
                      </tr>

                      <tr>
                        <td>
                         <input type="number" name="fac_five" size="5" value="<?php echo $featured_fac[4];?>"><br>
                         <input type="number" name="fac_six" size="5" value="<?php echo $featured_fac[5];?>"><br>
                         <input type="number" name="fac_seven" size="5" value="<?php echo $featured_fac[6];?>"><br>
                         <input type="number" name="fac_eight" size="5" value="<?php echo $featured_fac[7];?>">
                        <td>
                      </tr>

                      <tr>
                        <td>Staff</td>
                      </tr>

                      <tr>
                        <td>
                         <input type="number" name="fac_nine" size="5" value="<?php echo $featured_fac[8];?>"><br>
                         <input type="number" name="fac_ten" size="5" value="<?php echo $featured_fac[9];?>"><br>
                         <input type="number" name="fac_eleven" size="5" value="<?php echo $featured_fac[10];?>"><br>
                         <input type="number" name="fac_twelve" size="5" value="<?php echo $featured_fac[11];?>">
                        <td>
                      </tr>
                  <tr>
                    <td colspan = "6" align="right"><input type="submit" name="submit" value="Update Now"></td>
                  </tr>
                </table>
              </form>
            </tr>
          </table>
        </div>
      </div>
    </div>
  </section>
</body>
</html>
