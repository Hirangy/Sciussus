<?php
  require_once"admin/connect.php";

  $select_stats = "SELECT * FROM stats WHERE stat_id = 1";
  $query_stats = mysqli_query($conn,$select_stats);
  while ($row = mysqli_fetch_array($query_stats)) {
    $gencount = $row['stat_two'];
  }
?>

<!DOCTYPE html>
<html>
<head>
 <link rel="icon" href="resources/SCIUS LOGO.png">
 <title>โครงการ วมว. มหาวิทยาลัยศิลปากร โรงเรียนสิรินธรราชวิทยาลัย</title>
 <link rel="stylesheet" href="style.css">
 <link rel="stylesheet" href="stylehome.css">
 <meta name="viewport" content="width=device-width, initial-scale=1.0">
 <meta charset="UTF-8">
 <meta http-equiv=Content-Type content="text/html; charset=utf-8">
 <style>

 @font-face {
   font-family: Silapakorn-Light;
   src: url(resources/silapakorn72-light_beta05.ttf);
 }
 @font-face {
   font-family: Silapakorn-Bold;
   src: url(resources/silapakorn72-bold_beta05.ttf);
 }
 @font-face {
   font-family: Silapakorn-Regular;
   src: url(resources/silapakorn72-regular_beta05.ttf);
 }
 @font-face {
   font-family: Silapakorn-Italic;
   src: url(resources/silapakorn72-italic_beta05.ttf);
 }

.footer {
   width: 100vw;
   background-color: #40826d;
   color: white;
   text-align: center;
   font-family: Silapakorn-Regular;
   padding: 1vw;
}

body {
  height: <?php echo 100+380*$gencount?>vw;
  background: linear-gradient(180deg, #fff  1%, #9fd5ff  5%, #dce7f2 20%, #eae6eb 40%, #f5e3d5 60%, #ffc184 80%, #ff6500 100%);
}

</style>
</head>
<body>


  <?php
  $i = 0;
   while ($i<$gencount) {
   $i++
   ?>
   <b id="number<?php echo $i;?>" text-align=center style="position:fixed; top:200vw; left:16vw; font-family:Silapakorn-Italic; font-size:120vw; color:#fff; opacity:0.85;"><?php echo $i;?></b>
   <?php } ?>
 <div id="desktop_elements">

   <img id="scrolldowndesktop" style="transition:1s; position:fixed; bottom:8vw; left:43vw; width:14vw;"src="img/scroll down.svg">


   <div style="position:absolute; top:0vw; left:0vw;">


         <?php
         $i = 0;
          while ($i<$gencount) {
          $i++;
         $j = 0;
         while ($j<100) {
             $j++;
       $select_stu = "SELECT * FROM student WHERE stu_gen = $i AND stu_no = $j";

       $query_stu = mysqli_query($conn,$select_stu);

       while ($row = mysqli_fetch_array($query_stu)) {
         $no = $row['stu_no'];
         $nick = $row['stu_nick'];
         $name = $row['stu_name'];
         $uni = $row['stu_uni'];
         $image = $row['stu_img'];
         $proj = $row['stu_proj'];

      ?>
      <div class="people">
        <svg style="position:absolute; top:<?php echo 69.5+($i-1)*350+8*($j+floor(($j-1)/3));?>vw; left:<?php echo (($j-1) % 3)*30+11.5; ?>vw;" width="19vw" height="25vw" viewBox="0 0 19 25">
          <rect x="0" y="0" rx="3" width="19" height="25" border="1" fill="#40826d"/>
        </svg>
        <img style="border-radius: 2.5vw; position:absolute; top:<?php echo 70+($i-1)*350+8*($j+floor(($j-1)/3));?>vw; left:<?php echo (($j-1) % 3)*30+12; ?>vw; width:18vw; height:24vw;"  src = "<?php echo $image;?>">
        <img style="position:absolute; top:<?php echo 84+($i-1)*350+8*($j+floor(($j-1)/3));?>vw; left:<?php echo (($j-1) % 3)*30+10; ?>vw; width:23vw;" src="img/nametag.svg">
        <svg style="position:absolute; top:<?php echo 80+($i-1)*350+8*($j+floor(($j-1)/3));?>vw; left:<?php echo (($j-1) % 3)*30+10; ?>vw; width:23vw; font-size:0.3vw; " viewBox="0 0 24 20">
        <text x="9" y="10.8" font-family="Silapakorn-Italic" transform="rotate(-7.62,0,0)" fill="#40826d" dominant-baseline="middle" text-anchor="middle" src="img/nametag.svg"><?php echo $nick; ?><text>
        </svg>
      </div>
    <?php }}} ?>

    <a href="studenttable.php">
      <img style="position:absolute; top:15vw; left:75vw; width:10vw;"  src="img/stu icon gallery.svg">
    </a>

  </div>

   <div id="desktop_menubar" style="position:absolute;">
       <div id="desktop_menubarbg">
         <img id="desktop_menubar_icons" src="resources/sciussu-menubar-icons.svg">
         <img id="desktop_menubar_longname" src="resources/sciussu-menubar-th-title.svg" >
         <svg id="desktop_menubar_rect" width="100vw" viewBox="0 0 80 8">
           <rect x="0" y="0" width="80" height="8" opacity=0.2 style="fill:#000"/>
           <rect x="0" y="0" width="80" height="7.65" style="fill:#40826d"/>
         </svg>
         <svg id="desktop_menubar_circle" height="16.8vw" viewBox="0 0 80 80">
           <circle cx="40" cy="40" r="35" style="fill:#40826d" />
         </svg>
         <b id="desktop_menubar_title_th">
           โครงการ วมว.
         </b>
         <b id="desktop_menubar_subtitle_th">
           โรงเรียนสิรินธรราชวิทยาลัย มหาวิทยาลัยศิลปากร
         </b>
       </div>

     <div id="desktop_iconlang">
       <div class="icon">
         <a href="index-en.php" height="9.4vw" width="6.25vw">
           <svg height="9.4vw" width="6.25vw" viewBox="0 0 80 120">
             <circle cx="40" cy="40" r="35" fill="white" opacity="0.1"/>
             <rect x="0" y="85" width="80" height="30" style="fill:#fff;stroke-width:4;stroke:#40826d"/>
             <text x="20" y="106" fill=#40826d style="font-size: 18px; font-family:Silapakorn-Bold;">ภาษา</text>
           </svg>
         </a>
       </div>
     </div>

     <div id="desktop_iconcont">
       <div class="icon">
         <a href="cont.php" height="9.4vw" width="6.25vw">
           <svg height="9.4vw" width="6.25vw" viewBox="0 0 80 120">
             <circle cx="40" cy="40" r="35" fill="white"opacity="0.1"/>
             <rect x="0" y="85" width="80" height="30" style="fill:#fff;stroke-width:4;stroke:#40826d"/>
             <text x="18" y="106" fill=#40826d style="font-size: 18px; font-family:Silapakorn-Bold;">ติดต่อ</text>
           </svg>
         </a>
       </div>
     </div>

     <div id="desktop_iconacti">
       <div class="icon">
         <a href="acti.php" height="9.4vw" width="6.25vw">
           <svg height="9.4vw" width="6.25vw" viewBox="0 0 80 120">
             <circle cx="40" cy="40" r="35" fill="white"opacity="0.1"/>
             <rect x="0" y="85" width="80" height="30" style="fill:#fff;stroke-width:4;stroke:#40826d"/>
             <text x="12" y="106" fill=#40826d style="font-size: 18px; font-family:Silapakorn-Bold;">กิจกรรม</text>
           </svg>
         </a>
       </div>
     </div>

     <div id="desktop_iconpers">
       <div class="icon">
         <a href="pers.php" height="9.4vw" width="6.25vw">
           <svg height="9.4vw" width="6.25vw" viewBox="0 0 80 120">
             <circle cx="40" cy="40" r="35" fill="white"opacity="0.1"/>
             <rect x="0" y="85" width="80" height="30" style="fill:#fff;stroke-width:4;stroke:#40826d"/>
             <text x="13" y="106" fill=#40826d style="font-size: 18px; font-family:Silapakorn-Bold;">บุคลากร</text>
           </svg>
         </a>
       </div>
     </div>

     <div id="desktop_iconnews">
       <div class="icon">
         <a href="news.php" height="9.4vw" width="6.25vw">
           <svg height="9.4vw" width="6.25vw" viewBox="0 0 80 120">
             <circle cx="40" cy="40" r="35" fill="white"opacity="0.1"/>
             <rect x="0" y="85" width="80" height="30" style="fill:#fff;stroke-width:4;stroke:#40826d"/>
             <text x="14" y="106" fill=#40826d style="font-size: 18px; font-family:Silapakorn-Bold;">ประกาศ</text>
           </svg>
         </a>
       </div>
     </div>

     <div id="desktop_iconinfo">
       <div class="icon">
         <a href="info.php" height="9.4vw" width="6.25vw">
           <svg height="9.4vw" width="6.25vw" viewBox="0 0 80 120">
             <circle cx="40" cy="40" r="35" fill="white"opacity="0.1"/>
             <rect x="0" y="85" width="80" height="30" style="fill:#fff;stroke-width:4;stroke:#40826d"/>
             <text x="4" y="106" fill=#40826d style="font-size: 14px; font-family:Silapakorn-Bold;">ข้อมูลเบื้องต้น</text>
           </svg>
         </a>
       </div>
     </div>

     <div id="desktop_iconhome">
       <div class="icon">
         <a href="index.php" height="9.4vw" width="6.25vw">
           <svg height="9.4vw" width="6.25vw" viewBox="0 0 80 120">
             <circle cx="40" cy="40" r="35" fill="white"opacity="0.1"/>
             <rect x="0" y="85" width="80" height="30" style="fill:#fff;stroke-width:4;stroke:#40826d"/>
             <text x="12" y="106" fill=#40826d style="font-size: 18px; font-family:Silapakorn-Bold;">หน้าหลัก</text>
           </svg>
         </a>
       </div>
     </div>
     <div id="desktop_logo">
       <a target="_blank" href="http://scius.most.go.th/">
       <img width = "100%" src="resources/SCIUS LOGO.png">
       </a>
     </div>
   </div>

  </div>
 <div id="mobile_elements">

   <?php
   $i = 0;
    while ($i<$gencount) {
    $i++;
   $j = 0;
   while ($j<100) {
       $j++;
 $select_stu = "SELECT * FROM student WHERE stu_gen = $i AND stu_no = $j";

 $query_stu = mysqli_query($conn,$select_stu);

 while ($row = mysqli_fetch_array($query_stu)) {
   $no = $row['stu_no'];
   $nick = $row['stu_nick'];
   $name = $row['stu_name'];
   $uni = $row['stu_uni'];
   $image = $row['stu_img'];
   $proj = $row['stu_proj'];

?>
<div class="people">
  <svg style="position:absolute; top:<?php echo 169.5+($i-1)*350+8*($j+floor(($j-1)/3));?>vw; left:<?php echo (($j-1) % 3)*30+11.5; ?>vw;" width="19vw" height="25vw" viewBox="0 0 19 25">
    <rect x="0" y="0" rx="3" width="19" height="25" border="1" fill="#40826d"/>
  </svg>
  <img style="border-radius: 2.5vw; position:absolute; top:<?php echo 170+($i-1)*350+8*($j+floor(($j-1)/3));?>vw; left:<?php echo (($j-1) % 3)*30+12; ?>vw; width:18vw; height:24vw;"  src = "<?php echo $image;?>">
  <img style="position:absolute; top:<?php echo 184+($i-1)*350+8*($j+floor(($j-1)/3));?>vw; left:<?php echo (($j-1) % 3)*30+10; ?>vw; width:23vw;" src="img/nametag.svg">
  <svg style="position:absolute; top:<?php echo 180+($i-1)*350+8*($j+floor(($j-1)/3));?>vw; left:<?php echo (($j-1) % 3)*30+10; ?>vw; width:23vw; font-size:1.2vw; " viewBox="0 0 24 20">
  <text x="9" y="10.8" font-family="Silapakorn-Italic" transform="rotate(-7.62,0,0)" fill="#40826d" dominant-baseline="middle" text-anchor="middle" src="img/nametag.svg"><?php echo $nick; ?><text>
  </svg>
</div>
<?php }}} ?>

   <div class="mobile_menubar">
     <div id="mobile_menubarbg">
       <img src="resources/sciussu-menubar-th-mobile.svg" >
     </div>

     <div id="mobile_logo">
       <a target="_blank" href="http://scius.most.go.th/">
       <img width = "100%" src="resources/SCIUS LOGO.png">
       </a>
     </div>

     <div id="mobile_iconlang">
       <div class="icon">
         <a href="index-en.html" height="15vw" width="15vw">
           <svg height="15vw" width="15vw" viewBox="0 0 80 80">
             <circle cx="40" cy="35" r="35" fill="white" opacity="0.1"/>
           </svg>
         </a>
       </div>
     </div>

     <div id="mobile_iconmenu">
       <div>
         <element onclick="menumobile_on()">
           <svg height="15vw" width="15vw" viewBox="0 0 80 80">
             <circle cx="40" cy="35" r="35" fill="white" opacity="0.0"/>
           </svg>
         </element>
       </div>
     </div>

     <div id="mobile_menu_on">
       <img src="resources/sciussu-mobile-menu-th.svg" >
       <div id="mobile_menu_off" class="icon">
         <element onclick="menumobile_off()">
           <svg height="15vw" width="15vw" viewBox="0 0 80 80">
             <circle cx="40" cy="35" r="35" fill="white" opacity="0.1"/>
           </svg>
         </element>
       </div>

       <div id="mobile_iconcont" class="icon">
         <a href="cont.php" height="9.4vw" width="40vw">
           <svg height="10vw" width="56vw" viewBox="0 0 56 10">
             <rect x="0" y="0" rx="4" ry="4" width="56" height="10" fill="white"opacity="0.1"/>
           </svg>
         </a>
       </div>

       <div id="mobile_iconacti" class="icon">
         <a href="acti.php" height="9.4vw" width="40vw">
           <svg height="10vw" width="56vw" viewBox="0 0 56 10">
             <rect x="0" y="0" rx="4" ry="4" width="56" height="10" fill="white"opacity="0.1"/>
           </svg>
         </a>
       </div>

       <div id="mobile_iconpers" class="icon">
         <a href="pers.php" height="9.4vw" width="40vw">
           <svg height="10vw" width="56vw" viewBox="0 0 56 10">
             <rect x="0" y="0" rx="4" ry="4" width="56" height="10" fill="white"opacity="0.1"/>
           </svg>
         </a>
       </div>

       <div id="mobile_iconnews" class="icon">
         <a href="news.php" height="9.4vw" width="40vw">
           <svg height="10vw" width="56vw" viewBox="0 0 56 10">
             <rect x="0" y="0" rx="4" ry="4" width="56" height="10" fill="white"opacity="0.1"/>
           </svg>
         </a>
       </div>

       <div id="mobile_iconinfo" class="icon">
         <a href="info.php" height="9.4vw" width="40vw">
           <svg height="10vw" width="56vw" viewBox="0 0 56 10">
             <rect x="0" y="0" rx="4" ry="4" width="56" height="10" fill="white"opacity="0.1"/>
           </svg>
         </a>
       </div>

       <div id="mobile_iconhome" class="icon">
         <a href="index.php" height="9.4vw" width="40vw">
           <svg height="10vw" width="56vw" viewBox="0 0 56 10">
             <rect x="0" y="0" rx="4" ry="4" width="56" height="10" fill="white"opacity="0.1"/>
           </svg>
         </a>
       </div>
   </div>


 </div>

 <img id="scrolldownmobile" style="transition:1s; position:fixed; bottom:12vw; left:38vw; width:24vw;"src="img/scroll down.svg">

</body>

<script>


function menumobile_on() {
document.getElementById("mobile_menu_on").style.display = "block";
document.getElementById("mobile_menu_on").style.opacity = "1";
document.getElementById("mobile_menu_off").style.display = "block";
}
function menumobile_off() {
document.getElementById("mobile_menu_on").style.display = "none";
document.getElementById("mobile_menu_on").style.opacity = "0";
}

window.onscroll = function() {scrollFunction()};

 function scrollFunction() {

   var x = document.documentElement.clientWidth;
   var y = document.documentElement.clientHeight;
   var k = -0.4;
   var h = window.pageYOffset;
   <?php
   $i=0;
   while ($i<$gencount) {
     $i++
     ?>
     var elem<?php echo $i?> = document.getElementById('number<?php echo $i?>');
     var pos<?php echo $i?> = 50*y/x-0.35*(100*h/x - <?php echo 350*$i-300;?> + 50 *y/x);
     elem<?php echo $i?>.style.top  = pos<?php echo $i?> + 'vw';
     <?php
   }
   ?>


   if(document.body.scrollLeft > 0 || document.documentElement.scrollLeft > 0){
    setTimeout(function(){ window.scrollBy(-100,0); }, 500);
}
 if (document.body.scrollTop > 80 || document.documentElement.scrollTop > 80) {
   document.getElementById("desktop_menubar_rect").style.top = "-30vw";
   document.getElementById("desktop_menubar_circle").style.top = "-100vw";
   document.getElementById("desktop_logo").style.width = "5.5vw";
   document.getElementById("desktop_logo").style.top = "-100vw";
   document.getElementById("desktop_menubar_title_th").style.top = "-100vw";
   document.getElementById("desktop_menubar_title_th").style.left = "8vw";
   document.getElementById("desktop_menubar_subtitle_th").style.opacity = "0";
   document.getElementById("desktop_menubar_subtitle_th").style.left = "8vw";
   document.getElementById("desktop_menubar_longname").style.top = "-100vw";
   document.getElementById("desktop_menubar_icons").style.top = "-105vw";
   document.getElementById("desktop_iconlang").style.top = "-100vw";
   document.getElementById("desktop_iconcont").style.top = "-100vw";
   document.getElementById("desktop_iconacti").style.top = "-100vw";
   document.getElementById("desktop_iconpers").style.top = "-100vw";
   document.getElementById("desktop_iconnews").style.top = "-100vw";
   document.getElementById("desktop_iconinfo").style.top = "-100vw";
   document.getElementById("desktop_iconhome").style.top = "-100vw";
 } else {
   document.getElementById("desktop_menubar_rect").style.top = "0vw";
   document.getElementById("desktop_menubar_circle").style.top = "-1.5vw";
   document.getElementById("desktop_logo").style.width = "12.8vw";
   document.getElementById("desktop_logo").style.top = "0.4vw";
   document.getElementById("desktop_menubar_title_th").style.top = "1vw";
   document.getElementById("desktop_menubar_title_th").style.left = "15.6vw";
   document.getElementById("desktop_menubar_subtitle_th").style.opacity = "1";
   document.getElementById("desktop_menubar_subtitle_th").style.left = "16vw";
   document.getElementById("desktop_menubar_longname").style.top = "0vw";
   document.getElementById("desktop_menubar_icons").style.top = "0vw";
   document.getElementById("desktop_iconlang").style.top = "1.6vw";
   document.getElementById("desktop_iconcont").style.top = "1.6vw";
   document.getElementById("desktop_iconacti").style.top = "1.6vw";
   document.getElementById("desktop_iconpers").style.top = "1.6vw";
   document.getElementById("desktop_iconnews").style.top = "1.6vw";
   document.getElementById("desktop_iconinfo").style.top = "1.6vw";
   document.getElementById("desktop_iconhome").style.top = "1.6vw";
 }
 if (document.body.scrollTop > 50 || document.documentElement.scrollTop > 50) {
   document.getElementById("scrolldowndesktop").style.bottom = "50vw";
   document.getElementById("scrolldowndesktop").style.opacity = "0";
   document.getElementById("scrolldownmobile").style.bottom = "50vw";
   document.getElementById("scrolldownmobile").style.opacity = "0";
 } else {
   document.getElementById("scrolldowndesktop").style.bottom = "8vw";
   document.getElementById("scrolldowndesktop").style.opacity = "1";
   document.getElementById("scrolldownmobile").style.bottom = "12vw";
   document.getElementById("scrolldownmobile").style.opacity = "0";
 }
}

</script>

</html>
