<?php
  require_once "connect.php";
  session_start();

  if (!isset($_SESSION['username'])) {
    header("location: login.php");
  } else {

      $select_stats = "SELECT * FROM stats WHERE stat_id = 1";
      $query_stats = mysqli_query($conn,$select_stats);
      while ($row = mysqli_fetch_array($query_stats)) {
        $gencount = $row['stat_two'];
      }

 ?>


<!DOCTYPE html>
<html>
<head>
 <link rel="icon" href="resources/SCIUS LOGO.png">
 <title>SCiUS View Students Page</title>
 <link rel="stylesheet" href="styleadmin.css">
 <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
  <header>
    <div class="container">
      <h1 style="font-family: Silapakorn-Regular;"> Welcome to the administrator page, <?php echo $_SESSION['username'];?></h1>
    </div>
  </header>
  <section>
    <div class="content" style="font-family: Silapakorn-Regular;">
      <div class="content_grid">
        <div class="sidebar">
          <h1>Welcome: <?php echo $_SESSION['username']?></h1>
          <h3><a href="index.php"> Home Page </a></h3>
          <hr>
          <h3><a href="viewposts.php"> View Posts </a></h3>
          <h3><a href="insertposts.php"> Insert Posts </a></h3>
          <hr>
          <h3><a href="viewactivities.php"> View Activities </a></h3>
          <h3><a href="insertactivities.php"> Insert Activities </a></h3>
          <hr>
          <h3><a href="viewfaculties.php"> View Faculties </a></h3>
          <h3><a href="insertfaculties.php"> Insert Faculties </a></h3>
          <hr>
          <h3><a href="logout.php"> Logout </a></h3>
        </div>
        <div class="showinfo" style="font-family: Silapakorn-Regular;">
          <h1>View All Activities</h1>

          <table border="1">

            <?php
                $i = 0;
                while ($i<$gencount) {
                $i++
                ?>
                <tr>
                <td> Gen <?php echo $i; ?> Students </td>
                </tr>
            <tr>
              <th> ID </th>
              <th> Gen </th>
              <th> No. </th>
              <th> Nickname </th>
              <th> Name </th>
              <th> University </th>
              <th> Image </th>
              <th> Project </th>
              <th> Delete </th>
              <th> Edit </th>
            </tr>



                <?php
                $j = 0;
                while ($j<100) {
                    $j++;
              $select_stu = "SELECT * FROM student WHERE stu_gen = $i AND stu_no = $j";

              $query_stu = mysqli_query($conn,$select_stu);

              while ($row = mysqli_fetch_array($query_stu)) {
                $id = $row['stu_id'];
                $gen = $row['stu_gen'];
                $no = $row['stu_no'];
                $nick = $row['stu_nick'];
                $name = $row['stu_name'];
                $uni = $row['stu_uni'];
                $image = $row['stu_img'];
                $proj = $row['stu_proj'];

             ?>
             <tr>
               <td><?php echo $id; ?></td>
               <td><?php echo $gen; ?></td>
               <td><?php echo $no; ?></td>
               <td><?php echo $nick; ?></td>
               <td><?php echo $name; ?></td>
               <td><?php echo $uni; ?></td>
               <td><a href="<?php echo $image; ?>">Link</a></td>
               <td><?php echo $proj; ?></td>

               <td><a href="deletestudents.php?del=<?php echo $id; ?>">Delete</a></td>
               <td><a href="editstudents.php?edit=<?php echo $id; ?>">Edit</a></td>
             </tr>


           <?php }}} ?>
          </table>
        </div>
      </div>
    </div>
  </section>
</body>
</html>

<?php } ?>
