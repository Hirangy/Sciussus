<?php
  session_start();
  require_once "connect.php";
  if (!isset($_SESSION['username'])) {
    header("location: login.php");
  }

  if (isset($_GET['edit'])) {
    $edit_id = $_GET['edit'];
    $edit_query = "SELECT * FROM student WHERE stu_id = '$edit_id'";
    $run_edit = mysqli_query($conn,$edit_query);
    while ($edit_row = mysqli_fetch_array($run_edit)) {
      $id = $edit_row['stu_id'];
      $gen = $edit_row['stu_gen'];
      $no = $edit_row['stu_no'];
      $nick = $edit_row['stu_nick'];
      $name = $edit_row['stu_name'];
      $uni = $edit_row['stu_uni'];
      $image = $edit_row['stu_img'];
      $proj = $edit_row['stu_proj'];
    }
  } else {
    header("location:viewstudents.php");
  }

  if (isset($_POST['submit'])) {

    $update_id = $_GET['edit_form'];
    $gen = $_POST['gen'];
    $no = $_POST['no'];
    $nick = $_POST['nick'];
    $name = $_POST['name'];
    $uni = $_POST['uni'];
    $image = $_POST['image'];
    $proj = $_POST['proj'];


    $update_query = "UPDATE student SET stu_gen = '$gen', stu_no = '$no',stu_nick = '$nick',stu_name = '$name',stu_uni = '$uni',stu_img = '$image',stu_proj = '$proj' WHERE stu_id = '$update_id'";

    if (mysqli_query($conn, $update_query)) {
      echo"<script>alert('Student Updated');</script>";
    } else {
      echo"<script>alert('Sum Ting Wong');</script>";
    }
  }

?>

<!DOCTYPE html>
<html>
<head>
 <link rel="icon" href="resources/SCIUS LOGO.png">
 <title>SCiUS Edit Student Page</title>
 <link rel="stylesheet" href="styleadmin.css">
 <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
  <header>
    <div class="container">
      <h1 style="font-family: Silapakorn-Regular;">Welcome to the administrator page, <?php echo $_SESSION['username'];?></h1>
    </div>
  </header>
  <section>
    <div class="content" style="font-family: Silapakorn-Regular;">
      <div class="content_grid">
        <div class="sidebar">
          <h1>Welcome: <?php echo $_SESSION['username']?></h1>
          <h3><a href="index.php"> Home Page </a></h3>
          <hr>
          <h3><a href="viewposts.php"> View Posts </a></h3>
          <h3><a href="insertposts.php"> Insert Posts </a></h3>
          <hr>
          <h3><a href="viewactivities.php"> View Activities </a></h3>
          <h3><a href="insertactivities.php"> Insert Activities </a></h3>
          <hr>
          <h3><a href="viewfaculties.php"> View Faculties </a></h3>
          <h3><a href="insertfaculties.php"> Insert Faculties </a></h3>
          <hr>
          <h3><a href="logout.php"> Logout </a></h3>
        </div>
        <div class="showinfo">

          <table border="1">
            <tr>
              <form action="editstudents.php?edit_form=<?php echo $id;?>" method="post" enctype="multipart/form-data">
                <table width="100%" align="center" border="1">
                  <tr>
                    <td align="center" colspan="6"><h1>Edit Student</h1></td>
                  </tr>
                  <tr>
                    <td>Gen</td>
                    <td><input type="text" name="gen" size="50" value="<?php echo $gen;?>"></td>
                  </tr>
                  <tr>
                    <td>Number</td>
                    <td><input type="text" name="no" size="50" value="<?php echo $no;?>"></td>
                  </tr>                  <tr>
                    <td>Nickname</td>
                    <td><input type="text" name="nick" size="50" value="<?php echo $nick;?>"></td>
                  </tr>                  <tr>
                    <td>Name</td>
                    <td><input type="text" name="name" size="50" value="<?php echo $name;?>"></td>
                  </tr>                  <tr>
                    <td>University</td>
                    <td><input type="text" name="uni" size="50" value="<?php echo $uni;?>"></td>
                  </tr>                  <tr>
                    <td>Project</td>
                    <td><input type="text" name="proj" size="50" value="<?php echo $proj;?>"></td>
                  </tr>
                  <tr>
                    <td>Image Link</td>
                    <td><img width="90" height="120" src="<?php echo $image; ?>"><input type="text" name="image" size="50" value="<?php echo $image;?>"><p>Will be scaled to 3:4</p></td>
                  </tr>
                  <tr>
                    <td colspan = "6" align="right"><input type="submit" name="submit" value="Update Now"></td>
                  </tr>
                </table>

              </form>
            </tr>
          </table>
        </div>
      </div>
    </div>
  </section>
</body>
</html>
